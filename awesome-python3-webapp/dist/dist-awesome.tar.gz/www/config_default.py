#coding:utf-8
configs = {
    'debug':True,
    'db': {
        'host': '127.0.0.1',
        'port': 3306,
        'user': '数据库用户名',
        'password': '数据库口令',
        'database': 'awesome'
    },
    'session': {
        'secret': 'Awesome'
    }
}